//-------------------------------------------------------------------------
//  Shutdown.cpp
//
//  Generic C++ local/remote computer shutdown implementation
//
//  Execution environment: Win32
//
//  Created: 2002
//
//  by Yuantu Huang
//-------------------------------------------------------------------------

#include <Windows.h>
#include "ShutDown.h"
#include "Str.h"

CShutdown::CShutdown(int flag, int seconds)
{
	Flag    = flag;
	Seconds = seconds;
}

const char* CShutdown::GetUsage()
{
	CStr buff = "Shutdown Local computer utility for Windows 9x/ME/NT/2000/XP version 1.02\n";
	buff += "Copyright (c) 2002 by Yuantu Huang\n\n";
	buff += "USAGE:\n";
	buff += "  shutdown [-dhr] [-t:seconds]\n\n";
	buff += "OPTIONS:\n";
	buff += "  -d         Shut down and power off, \n";
	buff += "             default timeout applied if no -t flag.\n";
	buff += "  -h         Shut down only (power off manually),\n";
	buff += "             default timeout applied if no -t flag.\n";
	buff += "  -r         Shut down and reboot,\n";
	buff += "             default timeout applied if no -t flag.\n";
	buff += "  -t:seconds Timeout in seconds before Power off, shutdown or reboot. \n";
	buff += "             During that time operation can be cenceled.\n";
	buff += "             Default timeout = 20 seconds.\n\n";
	buff += "EXAMPLES:\n\n";
	buff += "  1. Shut down and power off.\n";
	buff += "     shutdown -d -t:30\n";
	buff += "     shutdown -d\n\n";
	buff += "  2. Shut down and power off manually.\n";
	buff += "     shutdown -h -t:20\n";
	buff += "     shutdown -h\n\n";
	buff += "  3. Shut down and reboot.\n";
	buff += "     shutdown -r -t:10\n";
	buff += "     shutdown -r\n\n";
	buff += "NOTE:\n\n";
	buff += "-------------------------------\n";
	buff += "|    This is a freeware.      |\n";
	buff += "|    Use at your own risk!    |\n";
	buff += "-------------------------------\n";
	buff += "\nPress any key to quit.\n";

	return (const char*)buff;
}

void CShutdown::Usage()
{
	char ch;
	DWORD dwBytesWritten;
	const char* buff = GetUsage();

	// open the text output stream
	AllocConsole();
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	// write 'buff' to the console window
    WriteFile(h, buff, strlen(buff), &dwBytesWritten, NULL);
	// press any key in the console window to quit
	ReadFile(GetStdHandle(STD_INPUT_HANDLE), &ch, 1, &dwBytesWritten, NULL);
	FreeConsole(); 
}

BOOL CShutdown::CheckNTPrivilege()
{
	HANDLE hToken; 
	TOKEN_PRIVILEGES tkp; 
 
	// Get a token for this process. 
	if (!OpenProcessToken(GetCurrentProcess(), 
			TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken)) 
		return FALSE; 
 
	// Get the LUID for the shutdown privilege. 
	LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, 
			&tkp.Privileges[0].Luid); 
 
	tkp.PrivilegeCount = 1;  // one privilege to set    
	tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED; 
 
	// Get the shutdown privilege for this process. 
	AdjustTokenPrivileges(hToken, FALSE, &tkp, 0, 
			(PTOKEN_PRIVILEGES)NULL, 0); 
 
	// Cannot test the return value of AdjustTokenPrivileges. 
	if (GetLastError() != ERROR_SUCCESS) 
		return FALSE;  

	return TRUE;
}

BOOL CShutdown::ShutdownNow()
{
	if (GetVersion() & 0x80000000); // Windows 9x/ME
	else if (!CheckNTPrivilege())   // Windows NT/2000/XP
		return FALSE;

	// Shut down the system and force all applications to close. 
	switch(Flag)
	{
	case 1:	
		return ExitWindowsEx(EWX_POWEROFF | EWX_FORCE, 0); // power off
    case 2:	
		return ExitWindowsEx(EWX_SHUTDOWN | EWX_FORCE, 0); // halt
	case 3:	
		return ExitWindowsEx(EWX_REBOOT | EWX_FORCE, 0);   // reboot
	}
	
	return FALSE;
}

BOOL CShutdown::ShutdownNow(char* RemoteName, int Seconds, BOOL Reboot)
{
	HANDLE hToken;              // handle to process token 
	TOKEN_PRIVILEGES tkp;       // pointer to token structure 
 
	// Get the current process token handle so we can get 
	// shutdown privilege. 
	if (!OpenProcessToken(GetCurrentProcess(), 
			TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken)) 
		return FALSE;
 
	// Get the LUID for shutdown privilege. 
 	if (!LookupPrivilegeValue(RemoteName, SE_REMOTE_SHUTDOWN_NAME, 
			&tkp.Privileges[0].Luid))
		return FALSE;
 
	tkp.PrivilegeCount = 1;  // one privilege to set    
	tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED; 
	// Get shutdown privilege for this process. 
 	AdjustTokenPrivileges(hToken, FALSE, &tkp, sizeof(tkp), 
		(PTOKEN_PRIVILEGES) NULL, 0); 
 
	// Cannot test the return value of AdjustTokenPrivileges. 
 	if (GetLastError() != ERROR_SUCCESS) 
		return FALSE;

	CStr Msg;
	Msg.Format("The computer will be shutdown after %d minutes", Seconds);
	// Display the shutdown dialog box and start the time-out countdown. 
	BOOL fResult = InitiateSystemShutdown(RemoteName, 
					(char*)Msg,
					Seconds,	// time-out period 
					1, Reboot);	// reboot after shutdown if Reboot == 1
 
	if (!fResult) //failed to shutdown the remote computer
		return FALSE;
 
	// Disable shutdown privilege. 
	tkp.Privileges[0].Attributes = 0; 
	AdjustTokenPrivileges(hToken, FALSE, &tkp, sizeof(tkp), 
			 			 (PTOKEN_PRIVILEGES) NULL, 0); 
 
	if (GetLastError() != ERROR_SUCCESS) 
		return FALSE;

	return TRUE;
}

BOOL CShutdown::ParseCmdLine(char* CmdLine)
{
	char* pStr = strtok((char*)CmdLine, " \t");
	while(pStr)
	{
		if (!strncmp(pStr, "-d", 2) || !strncmp(pStr, "-D", 2))
			Flag = 1;
		else if (!strncmp(pStr, "-h", 2) || !strncmp(pStr, "-H", 2))
			Flag = 2;
		else if (!strncmp(pStr, "-r", 2) || !strncmp(pStr, "-R", 2))
			Flag = 3;
		else if ((!strncmp(pStr, "-t:", 3) || !strncmp(pStr, "-T:", 3) &&
			strlen(pStr) > 3))
			Seconds = atoi(&pStr[3]);

		pStr = strtok(NULL, " \t");
	} 

	if (Flag == 0 && Flag > 3)
	{
		Usage();
		return FALSE;
	}

	if (Seconds < 5)  Seconds = 5;
	if (Seconds > 86400) Seconds = 86400; // one day
	
	return TRUE;
}

void CShutdown::ShutdownAll(int Seconds, BOOL Reboot)
{
	DWORD result;
	WSADATA wsaData;
	// initialise windows socket
	WSAStartup(MAKEWORD(1,1), &wsaData);

	HANDLE hEnum;
	// start an enumeration of network resources 
	result = WNetOpenEnum(RESOURCE_CONTEXT, RESOURCETYPE_ANY, NULL, NULL, &hEnum);
	if (result == NO_ERROR && hEnum)
	{		
		const int items_at_a_time = 256;
		DWORD count;
		NETRESOURCE net_resource[items_at_a_time];
		DWORD net_resource_count;
		do 
		{
			count = -1;
			net_resource_count = sizeof(NETRESOURCE)*items_at_a_time;
			ZeroMemory(net_resource, net_resource_count);
			//enumeration of network resources 
			result = WNetEnumResource( hEnum, &count, (LPVOID)net_resource, &net_resource_count);
			if (result != NO_ERROR && result != ERROR_MORE_DATA)
				break;
			
			for (DWORD i = 0; i < count; i ++)
			{	
				if (net_resource[i].lpRemoteName)
				{
					// get remote computer name
					const char* RemoteName = net_resource[i].lpRemoteName;
					if (lstrlen(RemoteName) >= 2 && RemoteName[0] =='\\' && RemoteName[1] =='\\')
						RemoteName += 2; 
					if (gethostbyname(RemoteName))
						continue;

					// shutdown remote the computer
					CShutdown::ShutdownNow((char*)RemoteName, Seconds, Reboot);
				}
			}
		} 
		while(result == NO_ERROR || result == ERROR_MORE_DATA);
		
		WNetCloseEnum(hEnum);
	}
	WSACleanup();
}
