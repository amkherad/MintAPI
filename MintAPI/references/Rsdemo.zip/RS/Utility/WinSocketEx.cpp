//-------------------------------------------------------------------------
//  WinSocketEx.cpp
//
//  Generic C++ CWinSocket extension class implementation
//
//  Execution environment: Win32
//
//  Created: 2002
//
//  by Yuantu Huang
//-------------------------------------------------------------------------

#include "WinSocketEx.h"

const char* CWinSocketEx::GetStringByErrorCode(int ErrorCode)
{
	switch(ErrorCode)
	{
	case WSAEWOULDBLOCK:	return "Error code : WSAEWOULDBLOCK";
	case WSAEINPROGRESS:	return "Error code : WSAEINPROGRESS";   
	case WSAEALREADY:		return "Error code : WSAEALREADY";
	case WSAENOTSOCK:		return "Error code : WSAENOTSOCK";
	case WSAEDESTADDRREQ:	return "Error code : WSAEDESTADDRREQ";
	case WSAEMSGSIZE:		return "Error code : WSAEMSGSIZE";
	case WSAEPROTOTYPE:		return "Error code : WSAEPROTOTYPE";
	case WSAENOPROTOOPT:	return "Error code : WSAENOPROTOOPT";
	case WSAEOPNOTSUPP:		return "Error code : WSAEOPNOTSUPP";
	case WSAEPFNOSUPPORT:	return "Error code : WSAEPFNOSUPPORT";
	case WSAEAFNOSUPPORT:	return "Error code : WSAEAFNOSUPPORT";
	case WSAEADDRINUSE:		return "Error code : WSAEADDRINUSE";
	case WSAEADDRNOTAVAIL:	return "Error code : WSAEADDRNOTAVAIL";
	case WSAENETDOWN:		return "Error code : WSAENETDOWN";
	case WSAENETUNREACH:	return "Error code : WSAENETUNREACH";
	case WSAENETRESET:		return "Error code : WSAENETRESET";
	case WSAECONNABORTED:	return "Error code : WSAECONNABORTED";
	case WSAECONNRESET:		return "Error code : WSAECONNRESET";
	case WSAENOBUFS:		return "Error code : WSAENOBUFS";
	case WSAEISCONN:		return "Error code : WSAEISCONN";
	case WSAENOTCONN:		return "Error code : WSAENOTCONN";
	case WSAESHUTDOWN:		return "Error code : WSAESHUTDOWN";
	case WSAETOOMANYREFS:	return "Error code : WSAETOOMANYREFS";
	case WSAETIMEDOUT:		return "Error code : WSAETIMEDOUT";
	case WSAECONNREFUSED:	return "Error code : WSAECONNREFUSED";
	case WSAELOOP:			return "Error code : WSAELOOP";
	case WSAENAMETOOLONG:	return "Error code : WSAENAMETOOLONG";
	case WSAEHOSTDOWN:		return "Error code : WSAEHOSTDOWN";
	case WSAEHOSTUNREACH:	return "Error code : WSAEHOSTUNREACH";
	case WSAENOTEMPTY:		return "Error code : WSAENOTEMPTY";
	case WSAEPROCLIM:		return "Error code : WSAEPROCLIM";
	case WSAEUSERS:			return "Error code : WSAEUSERS";
	case WSAEDQUOT:			return "Error code : WSAEDQUOT";
	case WSAESTALE:			return "Error code : WSAESTALE";
	case WSAEREMOTE:		return "Error code : WSAEREMOTE";
	case WSAEDISCON:		return "Error code : WSAEDISCON";
	case WSASYSNOTREADY:	return "Error code : WSASYSNOTREADY";
	case WSAVERNOTSUPPORTED:return "Error code : WSAVERNOTSUPPORTED";
	case WSANOTINITIALISED:	return "Error code : WSANOTINITIALISED";
	case WSAHOST_NOT_FOUND:	return "Error code : WSAHOST_NOT_FOUND";
	case WSATRY_AGAIN:		return "Error code : WSATRY_AGAIN";
	case WSANO_RECOVERY:	return "Error code : WSANO_RECOVERY";
	case WSANO_DATA:		return "Error code : WSANO_DATA";
	case WSAEFAULT:			return "Error code : WSAEFAULT";
	case WSAEINTR:			return "Error code : WSAEINTR";
	default:				return "Unknown error code";
	}
}

BOOL CWinSocketEx::SetSockOpt(WORD On, WORD Timeout)
{
	int on = 1;
	linger linger;

    if(setsockopt(m_hSocket, SOL_SOCKET, SO_KEEPALIVE, (char*)&on, sizeof(on))<0)
		return FALSE;

	// if l_onoff == 1, a socket should remain open for a specified amount of time 
	// after a socket close call
    linger.l_onoff  = On;
    linger.l_linger = Timeout; // a minute time-out should be suitable
    if(setsockopt(m_hSocket, SOL_SOCKET, SO_LINGER, (char*)&linger, sizeof(linger))<0)
		return FALSE;

	return TRUE;
}

BOOL __stdcall CWinSocketEx::IsValidAddress(const void* lp, UINT nBytes, 
	BOOL bReadWrite)
{
	// simple version using Win-32 APIs for pointer validation.
	return (lp != NULL && !IsBadReadPtr(lp, nBytes) &&
		(!bReadWrite || !IsBadWritePtr((LPVOID)lp, nBytes)));
}

// recv helper
int CWinSocketEx::Receive(void* pBuf, int nBufLen, int nFlags)
{
	// validation of memory address
	if (!nBufLen || !IsValidAddress(pBuf, nBufLen))
		return 0;

	char* pRBuf = (char*)pBuf;
	memset(pRBuf, 0, nBufLen);
	int RecvBytes, TRLen = 0;
	// try to receive the complete message
	do
	{
		RecvBytes = CWinSocket::Receive(pRBuf + TRLen, nBufLen - TRLen, nFlags);
		if (RecvBytes == SOCKET_ERROR)
			return RecvBytes;
		TRLen += RecvBytes;
	}while(RecvBytes && TRLen < nBufLen && pRBuf[RecvBytes - 1]);

	return TRLen;
}
