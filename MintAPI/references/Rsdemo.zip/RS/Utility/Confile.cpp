//-------------------------------------------------------------------------
//  Confile.cpp
//
//  Generic C++ message logging and ini file reading implementation
//
//  Execution environment: Win32
//
//  Created: 2002
//
//  by Yuantu Huang
//-------------------------------------------------------------------------

#include <windows.h>
#include <io.h>
#include <fstream.h>
#include <stdio.h>

#include "Confile.h"

CStr CConfigFile::GetConfString(const CStr& Sect, const CStr& Item, const CStr& Default)
{
	char tmp[_MAX_PATH];
	CStr ret;

	GetPrivateProfileString(Sect, Item, Default, tmp, _MAX_PATH, m_IniFile);
	ret = tmp;
	return ret;
}

int CConfigFile::GetConfInt (const CStr& Section, const CStr& Item, int Default)
{
	return GetPrivateProfileInt(Section, Item, Default, m_IniFile);
}

bool CConfigFile::CheckExist(const CStr& Name)
{
	if (Name.IsEmpty())
		return false;

	if (!_access(Name, 0))
		return true;

	// can not access this file
	return false;
}

void CConfigFile::LogInit(const char *LogFile, const char *Version)
{
	if (!m_bDebug)
		return;

	if (!LogFile)
		m_LogFile [0] = '\0';

	_fullpath(m_LogFile, LogFile, _MAX_PATH);
	m_bLogInit = true;

	ofstream fLogFile (m_LogFile);
	
	// Get system time and date
	char szDate [40];
	char szTime [15];
	szDate [0] = '\0';
	szTime [0] = '\0';
	GetDateFormat (0, DATE_LONGDATE, NULL, NULL, szDate, sizeof (szDate));
	GetTimeFormat (0, TIME_FORCE24HOURFORMAT, NULL, NULL, szTime, sizeof (szTime));
	
	// Write file header
	fLogFile << "*******************************************************" << endl;
	fLogFile << m_LogFile << " LOG FILE" << endl;
	fLogFile << szDate << " , " << szTime << endl;
	fLogFile << "Software version: " << Version << endl;
	fLogFile << "*******************************************************" << endl;
}

void CConfigFile::LogMsg(const char *Function, int nLine, const char *Fmt, ...)
{
	if (!m_bDebug)
		return;

	if (!strlen (m_LogFile))
		return;

	Lock();

	// Get system time and date
	char szDate [40];
	char szTime [15];
	szDate [0] = '\0';
	szTime [0] = '\0';
	GetDateFormat (0, DATE_LONGDATE, NULL, NULL, szDate, sizeof (szDate));
	GetTimeFormat (0, TIME_FORCE24HOURFORMAT, NULL, NULL, szTime, sizeof (szTime));
	
	// Unpack variable argument list
	va_list ArgPtr;
	va_start (ArgPtr, Fmt);
	vsprintf (m_LogText, Fmt, ArgPtr);
	va_end (ArgPtr);

	// Log error
	ofstream fLogFile (m_LogFile, ios::app, filebuf::openprot);
	fLogFile << szDate << " , " << szTime << endl;
	if (Function)
	{
		fLogFile << "Function: " << Function << endl;
		fLogFile << "Index:    " << nLine << endl;
	}
	fLogFile << m_LogText << endl;
	fLogFile << "-------------------------------------------------------" << endl;
	
	Unlock();
}

void CConfigFile::LogEnd() 
{
	// cleanup log object
}
