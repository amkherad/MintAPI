//-------------------------------------------------------------------------
//  Rsh.cpp
//
//  Generic C++ remote shell implementation
//
//  Execution environment: Win32
//
//  Created: 2002
//
//  by Yuantu Huang
//-------------------------------------------------------------------------

#include <iostream.h>
#include <stdio.h>
#include <process.h>
#include "Rsh.h"

// validate the host name
BOOL CRshSocket::CheckHostName(const char* HostName)
{
	memset(&m_SockAddr, 0, sizeof(m_SockAddr));
	m_SockAddr.sin_addr.s_addr = inet_addr(HostName);
	if (m_SockAddr.sin_addr.s_addr == INADDR_NONE)
	{
		// if no such address avaliable, try to give it from system
		hostent* Host = gethostbyname(HostName);
		if (!Host)
			return FALSE;

		memcpy(&m_SockAddr.sin_addr.s_addr, Host->h_addr, Host->h_length);
	}

	return TRUE;
}

// temp error socket is used to receive the error messages
BOOL CRshSocket::OpenTempSocket()
{
	// create socket and bind to the valid reserved port (523-1023)
	if (!RResvPort())
		return FALSE;

	// set socket option
	if (!SetSockOpt(0))
	{
		Close();
		return FALSE;
	}

	// listen and ready to accept the client to connect
	if (!Listen())
	{
		Close();
		return FALSE;
	}

	return TRUE;
}

// try to duplicate the BSD rresvport function
BOOL CRshSocket::RResvPort(int Port)
{
    m_hSocket = socket(AF_INET, SOCK_STREAM, Port);
    if (m_hSocket == INVALID_SOCKET)
        return FALSE;
    
    sockaddr_in Addr;
    Addr.sin_family = AF_INET;
    Addr.sin_addr.s_addr = INADDR_ANY;
	// use BSD rresvport (513-1023) only 
	for(WORD nPort = IPPORT_RESERVED - 1; nPort > IPPORT_RESERVED / 2; nPort --)
    {
        Addr.sin_port = htons(nPort);
        if (Bind((sockaddr*)&Addr, sizeof(Addr)))
        {
			m_nPort = nPort;
            return TRUE;
        }
		// something wrong, no available port any more
        if (WSAGetLastError() != WSAEADDRINUSE)
            break;
    }

    Close();

    return FALSE;
}

BOOL CRshSocket::Connect()
{
	m_SockAddr.sin_family = AF_INET;
	m_SockAddr.sin_port   = m_nPort;
	if (!CWinSocket::Connect((sockaddr*)&m_SockAddr, sizeof(m_SockAddr)))
	{
		cout << "Can not connect to the RSHD daemon. Try it later on!";
		return FALSE;
	}

	return TRUE;
}

void CRshSocket::CloseSock(BOOL bCloseSock)
{
	if (bCloseSock)
		Close();
	delete this;
}

BOOL CRshSocket::Create(UINT nSocketPort, int nSocketType,  char*  pSocketAddress)
{
	// init only once please
	if (!SocketInit())
		return FALSE;

    if (m_hSocket != INVALID_SOCKET)
        return FALSE;

	// get port number
	servent* pService = getservbyname("shell", "tcp");
	if (!pService)
		return FALSE;

	// get protocol number
	LPPROTOENT pProtocol = getprotobyname("tcp");
	short int nProtocol;
	if (!pProtocol)
		nProtocol = IPPROTO_TCP; // use default protocol
	else
		nProtocol = pProtocol->p_proto;

	if (!RResvPort(nProtocol))
	    return FALSE;

	// set socket option
	SetSockOpt();
	m_nPort = htons(pService->s_port);

	// validate the host name
	if (!CheckHostName(GetRsh()->GetHostName()))
	{
		cout << "Unknown host: " << (const char*)GetRsh()->GetHostName() << endl;
		Close();
		return FALSE;
	}

	return TRUE;
}

//////////////////////////////////////////////////////////////////
CRsh::CRsh()
{
	m_pClientRsh   = NULL;
	m_pServerRsh   = NULL;
	m_pErrorRsh	   = NULL;
	m_bThreadAlive = FALSE;
}

void CRsh::RshUsage()
{
	cout<< endl
		<< "Remote shell utility for Windows 9x/NT/2000/XP ver 1.00" << endl
		<< "Copyright (c) 2002  by Yuantu Huang (yuantuh@techsim.com.au) " << endl
		<< endl
		<< "USAGE:" << endl
		<< "  rsh host [-l user] command " << endl
		<< "OPTIONS:" << endl
		<< "  -l user   Specifies that rsh is to log into the remote host " << endl
		<< "            as user instead of the local username. If this option " << endl
		<< "            is not specified, the local and remote usernames are the same." << endl
		<< endl
		<< "EXAMPLES:" << endl
		<< endl
		<< "  1. List all files in the root dir C:, and do not specify the user name." << endl
		<< "     rsh MINT dir C:\\" << endl
		<< "     Where MINT is the host name." << endl
		<< endl
		<< "  2. Run Notepad in MINT." << endl
		<< "     rsh MINT notepad" << endl
		<< endl
		<< "  3. List all files in the root dir C:, and specify the user name Dog." << endl
		<< "     rsh MINT -l Dog dir C:\\" << endl
		<< endl
		<< "NOTE:" <<endl
		<< endl
		<< "------------------------------------" << endl
		<< "*    This is a freeware.           *" << endl
		<< "*    Use at your own risk !        *" << endl
		<< "------------------------------------" << endl;
}

BOOL CRsh::ProcessShellCommand(int argc, char** argv)
{
	int n;
	if (argc < 3)
		return FALSE;

	// the second command line parameter must be remote host name
	m_HostName = argv[1];

	// user name followed by the -l flag
	if ((strcmp(argv[2], "-l") == 0) || (strcmp(argv[2], "-L") == 0))
	{
		// missing user name or the command
		if (argc < 5)
			return FALSE;

		// we assume the forth command line parameter is user name
		m_UserName = argv[3];
		n = 4;
	}
	else
	{
		// no user name provided, give it from the system
		char UserName[32];
	    DWORD Size = 32;
	    GetUserName(UserName, &Size);
		m_UserName = UserName;
		n = 2;
	}

	// the remain should be command
	m_Cmd = argv[n];
	for(int i = n + 1; i < argc; i ++)
	{
		m_Cmd += " ";
		m_Cmd += argv[i];
	}

	return TRUE;
}

void CRshSocket::CreateTempSocket()
{
	CRshSocket* pErrorRsh  = GetRsh()->GetErrorRsh(); 
	pErrorRsh = new CRshSocket;

	// waiting for error message coming
	GetRsh()->SetTreadAliveFlag(TRUE);
	if (!Accept(pErrorRsh))
	{
		if (m_hSocket != INVALID_SOCKET)
		{
			ShutDown();
			CloseSock();
			delete pErrorRsh;
			pErrorRsh = NULL;
		}
		cout << "Can not accept the error output socket" << endl;
		return;
	}

	char Buff[MSG_LEN];
	// if receiving buffer is not empty, the command may be wrong
	while(pErrorRsh->Receive(Buff, sizeof(Buff)) > 0)
		cout << Buff;

	// destroy the error socket and close the temp socket (pServerRsh) 
	GetRsh()->SetTreadAliveFlag(FALSE);
	if (pErrorRsh)
	{
		delete pErrorRsh;
		pErrorRsh = NULL;
		ShutDown();
		CloseSock();
	}
}

static void ServerThread(void* pData)
{
	CRshSocket* pServerRsh = (CRshSocket*)pData;
	pServerRsh->CreateTempSocket();
}

BOOL CRsh::CreateSock()
{
	// create and open the Rsh socket for receiving data from the remote
	m_pClientRsh = new CRshSocket(this);
	if (!m_pClientRsh->Create())
	{
		m_pClientRsh->CloseSock(FALSE);
		return FALSE;
	}

	// create and open a temp socket for receiving error messages
	m_pServerRsh = new CRshSocket(this);
	if (!m_pServerRsh->OpenTempSocket())
	{
		m_pServerRsh->CloseSock(FALSE);
		m_pClientRsh->CloseSock();
		return FALSE;
	}

	// connect to Rsh daemon
	if (!m_pClientRsh->Connect())
	{
		m_pServerRsh->CloseSock();
		m_pClientRsh->CloseSock();
		return FALSE;
	}

	// create thread for receiving error information
	if (_beginthread(ServerThread, 0, (void*)m_pServerRsh) == -1)
	{
		m_pServerRsh->CloseSock();
		m_pClientRsh->ShutDown();
		m_pClientRsh->CloseSock();
		return FALSE;
	}

	return TRUE;
}

void CRsh::ExecRshCommand()
{
	char Buff[MSG_LEN];
	memset(Buff, 0, sizeof(Buff));
	// prepare for commam buffer sending to Rsh daemon
	sprintf(Buff, "%d", m_pServerRsh->GetPort());
	int Len = strlen(Buff) + 1;
	strcpy(Buff + Len, m_UserName); 
	Len += strlen(m_UserName) + 1;
	strcpy(Buff + Len, m_UserName);
	Len += strlen(m_UserName) + 1;
	strcpy(Buff + Len, (const char*)m_Cmd);
	Len += strlen((const char*)m_Cmd) + 1;
	if (m_pClientRsh->Send(Buff, Len) == Len)
	{
		// waiting for receiving the result
		while(m_pClientRsh->Receive(Buff, sizeof(Buff)) > 0)
			 cout << Buff;
	}

	m_pClientRsh->ShutDown();
	m_pClientRsh->CloseSock();

	// waiting for error server sock to exit (one second should be enough)
	while(m_bThreadAlive)
	{
		static int i = 0;
		Sleep(20);
		if (++ i > 200) // 4 seconds waiting for error socket to accept
		{
			// the error output socket is trapping in accept, force exit!!!
			cout << "The error output socket is trapping in accept" << endl;
			if (m_pErrorRsh)
			{
				if (m_pServerRsh && m_pServerRsh->m_hSocket != INVALID_SOCKET)
				{
					m_pServerRsh->ShutDown();
					m_pServerRsh->CloseSock();
				}
				Sleep(1000);
				if (m_pErrorRsh)
				{
					delete m_pErrorRsh;
					m_pErrorRsh = NULL;
				}
			}
			m_bThreadAlive = FALSE;
		}
	}
}

int main(int argc, char *argv[])
{
	CRsh Rsh;

	// check and parse command line
	if (!Rsh.ProcessShellCommand(argc, argv))
	{
		Rsh.RshUsage();
		return 1;
	}

	// create Rsh sockets
	if (!Rsh.CreateSock())
		return 1;

	// execute the remote shell commmand
	Rsh.ExecRshCommand();

	return 0;
}
