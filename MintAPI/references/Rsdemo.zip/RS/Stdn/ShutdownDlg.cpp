// ShutdownDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Stdn.h"
#include "ShutdownDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CShutdownDlg dialog

CShutdownDlg::CShutdownDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CShutdownDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CShutdownDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_nSeconds = 20;
}

void CShutdownDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CShutdownDlg)
	DDX_Control(pDX, IDC_TYPE, m_Type);
	DDX_Control(pDX, IDOK, m_IdOk);
	DDX_Control(pDX, IDCANCEL, m_Cancel);
	DDX_Control(pDX, IDC_COUNTER, m_Counter);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CShutdownDlg, CDialog)
	//{{AFX_MSG_MAP(CShutdownDlg)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_TYPE, OnType)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShutdownDlg message handlers

BOOL CShutdownDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	int Flag   = ((CStdnApp*)AfxGetApp())->pShutdown->GetFlag();
	m_nSeconds = ((CStdnApp*)AfxGetApp())->pShutdown->GetSeconds();
	switch(Flag)
	{
	case 1:	
		m_Text = "The Window will be power off after";
		m_Type.SetWindowText("Poweroff now");
		break;
    case 2:	
		m_Text = "The Window will shutdown after";
		m_Type.SetWindowText("Shutdown now");
		break;
	case 3:	
		m_Text = "The Window will reboot after";
		m_Type.SetWindowText("Reboot now");
		break;
	}

	CString str;
	str.Format(" %d seconds", m_nSeconds);
	m_Counter.SetWindowText(m_Text + str);
	m_IdOk.ShowWindow(SW_HIDE);
	SetTimer(1, 1000, NULL);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CShutdownDlg::OnTimer(UINT nIDEvent) 
{
	CString str;
	str.Format(" %d seconds", -- m_nSeconds);
	m_Counter.SetWindowText(m_Text + str);
	if (m_nSeconds == 0)
		OnType();
	
	CDialog::OnTimer(nIDEvent);
}

void CShutdownDlg::OnType() 
{
	KillTimer(1);
	if (!((CStdnApp*)AfxGetApp())->pShutdown->ShutdownNow())
	{
		m_Counter.SetWindowText("Fail to showdown !!!");
		m_IdOk.ShowWindow(SW_SHOW);
		m_Type.ShowWindow(SW_HIDE);
		m_Cancel.ShowWindow(SW_HIDE);
	}
}
