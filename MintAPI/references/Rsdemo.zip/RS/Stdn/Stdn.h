// Stdn.h : main header file for the STDN application
//

#if !defined(AFX_STDN_H__F3131DF5_3FBB_44E4_8912_AAEE3DE7879A__INCLUDED_)
#define AFX_STDN_H__F3131DF5_3FBB_44E4_8912_AAEE3DE7879A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "Shutdown.h"

/////////////////////////////////////////////////////////////////////////////
// CStdnApp:
// See Stdn.cpp for the implementation of this class
//

class CStdnApp : public CWinApp
{
public:
	CStdnApp();
	CShutdown* pShutdown;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStdnApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CStdnApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDN_H__F3131DF5_3FBB_44E4_8912_AAEE3DE7879A__INCLUDED_)
