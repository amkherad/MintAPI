//-------------------------------------------------------------------------
//  Shutdown.h
//
//  Generic C++ local/remote computer shutdown header file
//
//  Execution environment: Win32, MFC
//
//  Created: 2002
//
//  by Yuantu Huang
//-------------------------------------------------------------------------

#ifndef __SHUTDOWN_H__
#define __SHUTDOWN_H__

//#include <winsock.h>

class CShutdown
{
public:
	CShutdown(int flag, int seconds);
	void Usage();
	BOOL ShutdownNow();
	void ShutdownAll(int Seconds = 20, BOOL Reboot = FALSE);
	BOOL ParseCmdLine(char* CmdLine);
	int  GetFlag()		{ return Flag; }
	int  GetSeconds()	{ return Seconds; }

private:
	int	Flag;					// shutdown flag 
	int Seconds;				// shutdown time delay
	CString GetUsage();
	BOOL CheckNTPrivilege();	// for NT/2000/XP only
	BOOL ShutdownNow(char* RemoteName, int Seconds = 20, BOOL Reboot = FALSE);
};

#endif
