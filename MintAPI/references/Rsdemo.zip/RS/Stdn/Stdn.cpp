// Stdn.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Stdn.h"
#include "ShutdownDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStdnApp

BEGIN_MESSAGE_MAP(CStdnApp, CWinApp)
	//{{AFX_MSG_MAP(CStdnApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStdnApp construction

CStdnApp::CStdnApp()
{
	pShutdown = new CShutdown(0, 20);
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CStdnApp object

CStdnApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CStdnApp initialization

BOOL CStdnApp::InitInstance()
{
	CString Option = m_lpCmdLine;

	if (Option.IsEmpty())
		pShutdown->Usage();
	else if (pShutdown->ParseCmdLine(m_lpCmdLine))
	{
		CShutdownDlg dlg;
		dlg.DoModal();
	}
	delete pShutdown;

	return FALSE;
}
