//-------------------------------------------------------------------------
//  Rsh.h
//
//  Generic C++ remote shell header file
//
//  Execution environment: Win32
//
//  Created: 2002
//
//  by Yuantu Huang
//-------------------------------------------------------------------------

#ifndef __RSH_H__
#define __RSH_H__

#include "WinSocketEx.h"
#include "Str.h"

class CRsh;

class CRshSocket : public CWinSocketEx
{
public:
	CRshSocket() {}
	CRshSocket(CRsh* pRsh)	{ m_pRsh = pRsh; }

// properties
	CRsh* GetRsh()			{ return m_pRsh; }
	int   GetPort()			{ return m_nPort;}

// Operations
	BOOL CheckHostName(const char* HostName);
	BOOL OpenTempSocket();
	BOOL RResvPort(int Port = 0);
	BOOL Connect();
	void CreateTempSocket();
	void CloseSock(BOOL bCloseSock = TRUE);

// Overrides
public:
	virtual ~CRshSocket() {}
	virtual BOOL Create(UINT nSocketPort = 0, int nSocketType = SOCK_STREAM, 
		char* pSocketAddress = NULL);

private:
	CRsh*		m_pRsh;
	sockaddr_in m_SockAddr;
	int			m_nPort;
};

class CRsh
{
public:
	CRsh();

// Properties
	CRshSocket* GetErrorRsh() const			{ return m_pErrorRsh; }
	void SetTreadAliveFlag(BOOL bl)			{ m_bThreadAlive = bl; }			
	const BOOL GetThreadAliveFlag() const	{ return m_bThreadAlive; }
	const CStr GetHostName() const			{ return m_HostName; }

// Operations
	void RshUsage();
	BOOL ProcessShellCommand(int argc, char** argv);
	BOOL CreateSock();
	void ExecRshCommand();

private:
	CStr		m_HostName;
	CStr		m_UserName;
	CStr		m_Cmd;
	CRshSocket* m_pClientRsh;
	CRshSocket* m_pServerRsh;
	CRshSocket* m_pErrorRsh;
	BOOL		m_bThreadAlive;
};

#endif
