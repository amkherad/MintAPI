//-------------------------------------------------------------------------
//  WinSocket.cpp
//
//  Generic C++ Win32 socket wrapper class implementation
//
//  Execution environment: Win32
//
//  Created: 2002
//
//  by Yuantu Huang
//-------------------------------------------------------------------------

#include "WinSocket.h"

CWinSocket::CWinSocket()
{ 
	m_hSocket = INVALID_SOCKET; 
}

static void SocketCleanup()
{   
    WSACleanup();   
}

BOOL CWinSocket::SocketInit()
{
	// initialize Winsock library (V1.1) or up
    WSAData WS_data;
    if (WSAStartup(MAKEWORD(1,1), &WS_data))
        return FALSE;

	if (LOBYTE(WS_data.wVersion) != 1 || HIBYTE(WS_data.wVersion) != 1)
	{
		WSACleanup();
		return FALSE;
	}

	// let operating system automatically invoke RshdSocketCleanup 
	// before terminating this process
	atexit(SocketCleanup);

    return TRUE;
}

BOOL CWinSocket::Create(UINT nSocketPort, int nSocketType,  char*  pSocketAddress)
{
    if (m_hSocket != INVALID_SOCKET)
        return FALSE;

    m_hSocket = socket(PF_INET, nSocketType, 0); // 0=default protocol
    if (m_hSocket == INVALID_SOCKET)
        return FALSE;

    if (Bind(nSocketPort,pSocketAddress))
        return TRUE;

    int nResult = GetLastError();
    Close();
    WSASetLastError(nResult);

    return FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// CWinSocket Attributes

BOOL CWinSocket::GetPeerName(char *pPeerAddress, int MaxAddrLen, UINT& rPeerPort)
{
    sockaddr_in sockAddr;
    memset(&sockAddr, 0, sizeof(sockAddr));

    int nSockAddrLen = sizeof(sockAddr);
    
    BOOL bResult = GetPeerName((sockaddr*)&sockAddr, &nSockAddrLen);
    if (bResult)
    {
        rPeerPort = ntohs(sockAddr.sin_port);
        char *p;
        p = inet_ntoa(sockAddr.sin_addr);
        strncpy(pPeerAddress, p, MaxAddrLen);
    }
    return bResult;
}

BOOL CWinSocket::GetSockName(char* pSocketAddress, int MaxAddrLen, UINT& rSocketPort)
{
    sockaddr_in sockAddr;
    memset(&sockAddr, 0, sizeof(sockAddr));

    int nSockAddrLen = sizeof(sockAddr);
    BOOL bResult = GetSockName((sockaddr*)&sockAddr, &nSockAddrLen);
    if (bResult)
    {
        rSocketPort = ntohs(sockAddr.sin_port);
    
        char *p;
        p = inet_ntoa(sockAddr.sin_addr);
        strncpy(pSocketAddress, p, MaxAddrLen);
    }
    return bResult;
}

/////////////////////////////////////////////////////////////////////////////
// CWinSocket Operations

BOOL CWinSocket::Accept(CWinSocket* pClientSock, sockaddr* pSockAddr, int* pSockAddrLen)
{
    if (pClientSock->m_hSocket != INVALID_SOCKET)
        return FALSE;
        
    pClientSock->m_hSocket = accept(m_hSocket, pSockAddr, pSockAddrLen);
    
    return (pClientSock->m_hSocket != INVALID_SOCKET);
}

BOOL CWinSocket::Bind(UINT nSocketPort, char*  pSocketAddress)
{
    sockaddr_in sockAddr;
    memset(&sockAddr,0,sizeof(sockAddr));

    char* pAscii = pSocketAddress;

    sockAddr.sin_family = AF_INET;

    if (pAscii == NULL)
        sockAddr.sin_addr.s_addr = htonl(INADDR_ANY);
    else
    {
        DWORD lResult = inet_addr(pAscii);
        if (lResult == INADDR_NONE)     
        {
            WSASetLastError(WSAEINVAL);
            return FALSE;
        }
        sockAddr.sin_addr.s_addr = lResult;
    }
    sockAddr.sin_port = htons((u_short)nSocketPort);

    return Bind((sockaddr*)&sockAddr, sizeof(sockAddr));
}

void CWinSocket::Close()
{
    if (m_hSocket != INVALID_SOCKET)
    {
        closesocket(m_hSocket);
        m_hSocket = INVALID_SOCKET;
    }
}

BOOL CWinSocket::Connect(const char*  pHostAddress, UINT nHostPort)
{
    if (pHostAddress == NULL)
        return FALSE;

    sockaddr_in sockAddr;
    memset(&sockAddr,0,sizeof(sockAddr));

    const char* pAscii = pHostAddress;

    sockAddr.sin_family = AF_INET;

    sockAddr.sin_addr.s_addr = inet_addr(pAscii);
    if (sockAddr.sin_addr.s_addr == INADDR_NONE)
    {
        LPHOSTENT phost;
        phost = gethostbyname(pAscii);
        if (phost != NULL)
            sockAddr.sin_addr.s_addr = ((LPIN_ADDR)phost->h_addr)->s_addr;
        else
        {
            WSASetLastError(WSAEINVAL);
            return FALSE;
        }
    }
    sockAddr.sin_port = htons((u_short)nHostPort);

    return Connect((sockaddr*)&sockAddr, sizeof(sockAddr));
}

int CWinSocket::ReceiveFrom(void* pBuf, int nBufLen, 
            char* pSocketAddress, int MaxAddrLen, UINT& rSocketPort, int nFlags)
{
    sockaddr_in sockAddr;

    memset(&sockAddr, 0, sizeof(sockAddr));

    int nSockAddrLen = sizeof(sockAddr);
    int nResult = 
    ReceiveFrom(pBuf, nBufLen, (sockaddr*)&sockAddr, &nSockAddrLen, nFlags);
    if(nResult != SOCKET_ERROR)
    {
        rSocketPort = ntohs(sockAddr.sin_port);
        char *p;
        p = inet_ntoa(sockAddr.sin_addr);
        strncpy(pSocketAddress, p, MaxAddrLen);
    }
    return nResult;
}

int CWinSocket::SendTo(const void* pBuf, int nBufLen, UINT nHostPort, 
       char*  pHostAddress, int nFlags)
{
    sockaddr_in sockAddr;

    memset(&sockAddr,0,sizeof(sockAddr));

    char* pAscii = pHostAddress; 

    sockAddr.sin_family = AF_INET;
    if (pAscii == NULL)
        sockAddr.sin_addr.s_addr = htonl(INADDR_BROADCAST);
    else
    {
        sockAddr.sin_addr.s_addr = inet_addr(pAscii);
        if (sockAddr.sin_addr.s_addr == INADDR_NONE)
        {
            hostent *phost;
            phost = gethostbyname(pAscii);
            if (phost != NULL)
                sockAddr.sin_addr.s_addr = ((in_addr*)phost->h_addr)->s_addr;
            else
            {
                WSASetLastError(WSAEINVAL);
                return FALSE;
            }
        }
    }

    sockAddr.sin_port = htons((u_short)nHostPort);
    return SendTo(pBuf, nBufLen, (sockaddr*)&sockAddr, sizeof(sockAddr), nFlags);
}
