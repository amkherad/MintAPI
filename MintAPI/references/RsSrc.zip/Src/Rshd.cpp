//-------------------------------------------------------------------------
//  Rshd.cpp
//
//  Generic C++ remote shell daemon implementation
//
//  Execution environment: Win32
//
//  Created: 2002
//
//  by Yuantu Huang
//-------------------------------------------------------------------------

#include <stdio.h>
#include <process.h>
#include "Windows.h"
#include "Rshd.h"

CRshdConfigFile* CRshdSocket::GetLog()	
{
	return m_pRshd->m_pConfile;
}

BOOL CRshdSocket::Create(UINT nSocketPort, int nSocketType,  
						 char*  pSocketAddress)
{
    if (m_hSocket != INVALID_SOCKET)
        return FALSE;

	// get port number
	servent* pService = getservbyname("cmd", "tcp");
	if (!pService)
		return FALSE;
	nSocketPort = htons(pService->s_port);

	// get protocol number
	LPPROTOENT pProtocol = getprotobyname("tcp");
	short int nProtocol;
	if (!pProtocol)
		nProtocol = IPPROTO_TCP; // use default protocol
	else
		nProtocol = pProtocol->p_proto;

	// the current version PF_INET == AF_INET
    m_hSocket = socket(PF_INET, SOCK_STREAM, nProtocol);
    if (m_hSocket == INVALID_SOCKET)
        return FALSE;

    if (Bind(nSocketPort,NULL))
        return TRUE;

	// can not bind the nSocketPort
    int nResult = GetLastError();
    Close();
    WSASetLastError(nResult);

    return FALSE;
}

BOOL CRshdSocket::CheckClienInfo(char* HostName)
{
	sockaddr_in Addr;
    int Len = sizeof(Addr);
    if(!GetPeerName((sockaddr*)&Addr, &Len))
    {
        GetLog()->LogMsg("CheckClienInfo", 1, 
			GetStringByErrorCode(WSAGetLastError()));
        return FALSE;
    }

	Addr.sin_port = ntohs(Addr.sin_port);
	if (!CheckPort(Addr.sin_port))
		return FALSE;

	// validate the client address
	hostent* pHostent = gethostbyaddr((const char*)&Addr.sin_addr, 
									  sizeof(in_addr), AF_INET);
	if (!pHostent)
	{
		// try to use IP address if no host name
		BYTE a = Addr.sin_addr.S_un.S_un_b.s_b1;
		BYTE b = Addr.sin_addr.S_un.S_un_b.s_b2;
		BYTE c = Addr.sin_addr.S_un.S_un_b.s_b3;
		BYTE d = Addr.sin_addr.S_un.S_un_b.s_b4;
		sprintf(HostName, "%d.%d.%d.%d", a, b, c, d);
		if (!HostName)
		{
			GetLog()->LogMsg("CheckClienInfo", 2, 
			GetStringByErrorCode(WSAGetLastError()));
			return FALSE;
		}
	}
	else
	{
		// get the client host name
		strcpy(HostName, pHostent->h_name);
	}
	GetLog()->LogMsg("CheckClienInfo", 0, "Remote host name = %s", HostName);

	return TRUE;
}

void CRshdSocket::OpenTempSocket()
{
	// set socket options
	if (!SetSockOpt())
	{
		DeleteClientSock();
		GetLog()->LogMsg("OpenTempSocket", 1, "Can not set socket option");
		return;
	}

	char HostName[32];
	if (!CheckClienInfo(HostName))
	{
		DeleteClientSock();
		return;
	}

	char Buff[MSG_LEN];
	int Len = sizeof(Buff);
	// the buffer should be port number
	if (Receive(Buff, Len) <= 0)
	{
		DeleteClientSock();
		GetLog()->LogMsg("OpenTempSocket", 2, "No port number available");
		return;
	}

	// check port
	WORD nPort = (WORD)atoi(Buff);
	if (!CheckPort(nPort))
	{
		DeleteClientSock();
		return;
	}

	// open the second socket
	CRshdSocket* pErrorRshd = new CRshdSocket(GetRshd());
	if (!OpenErrorSocket(pErrorRshd, nPort, HostName))
	{
		DeleteClientSock();
		delete pErrorRshd;
		return;
	}

	GetRshd()->m_ClientList.AddTail(pErrorRshd);

	// the buffer should be the user name
	int i = 0;
	if (!ReceiveClientInfo(Buff, Len, i))
	{
		GetLog()->LogMsg("OpenTempSocket", 3, "Can not get any user name");
		DeleteClientSock();
		pErrorRshd->DeleteClientSock();
		return;
	}
	
	GetLog()->LogMsg("OpenTempSocket", 0, 
		"Remote user name '%s' is accesing the Rshd service", Buff + i);

	// check host and remote user name from the .rhosts file
	if(!CheckHostAndUserName(HostName, Buff + i))
	{
		GetLog()->LogMsg("OpenTempSocket", 4, 
			"Host name = '%s' : user name = '%s' have something wrong", 
			HostName, Buff + i);
		DeleteClientSock();
		pErrorRshd->DeleteClientSock();
        return;
	}

	// the buffer should be the user name
	if (!ReceiveClientInfo(Buff, Len, i))
	{
		GetLog()->LogMsg("OpenTempSocket", 5, "Can not get any user name");
		DeleteClientSock();
		pErrorRshd->DeleteClientSock();
		return;
	}

	// the buffer should be the command
	if (!ReceiveClientInfo(Buff, Len, i))
	{
		GetLog()->LogMsg("OpenTempSocket", 6, "Can not get the command");
		DeleteClientSock();
		pErrorRshd->DeleteClientSock();
		return; 
	}

	GetLog()->LogMsg("OpenTempSocket", 0, "Command: %s", Buff + i);

	// try to send the client only one byte to check the it status
    Buff[0] = 0;
    if (Send(Buff, 1) < 1)
	{
        GetLog()->LogMsg("OpenTempSocket", 7, 
			GetStringByErrorCode(WSAGetLastError()));
		DeleteClientSock();
		pErrorRshd->DeleteClientSock();
		return;
	}

	// Execute the command and send the results to the client
	ExecCommand(pErrorRshd, Buff + i);

	DeleteClientSock();
	pErrorRshd->DeleteClientSock();	
}

static void ClientThread(void* pData)
{
	CRshdSocket* pClientRshd = (CRshdSocket*)pData;
	pClientRshd->OpenTempSocket();
}

// accept clients and one thread for one client
BOOL CRshdSocket::Accept(CWinSocket* pClientRshd, sockaddr* pSockAddr, 
						 int* pSockAddrLen)
{
	while(TRUE)
	{
		pClientRshd = new CRshdSocket(GetRshd());
		Sleep(100);	
		if (CWinSocket::Accept(pClientRshd))
		{
			// start multitthread
			if (_beginthread(ClientThread, 0, (void*)pClientRshd) == -1)
				GetLog()->LogMsg("Accept", 1, "Can not create thread");
			GetRshd()->m_ClientList.AddTail((CRshdSocket*)pClientRshd);
		}
		else
			GetLog()->LogMsg("Accept", 2, 	
				GetStringByErrorCode(WSAGetLastError()));
	}

	return TRUE;
}

BOOL CRshdSocket::CheckPort(WORD nPort)
{
	// nPort must be one of the reserved ports
	// refer to DSB rresvport function specification
	if(nPort <= IPPORT_RESERVED / 2 || nPort > IPPORT_RESERVED - 1)
    {
        GetLog()->LogMsg("CheckPort", 1, 
			"Client port out of the 513-1023 range");
        return FALSE;
    }

	return TRUE;
}

BOOL CRshdSocket::CheckHostAndUserName(const char* HostName, 
									   const char* UserName)
{
	CRshd* pRshd = GetRshd();
	pRshd->m_Lock.Lock();

	CHostUserName Name;
	Name.HostName = HostName;
	Name.UserName = UserName;

	// iteration of the CHostUserNameList
	POSITION pos = pRshd->m_HostUserList.GetHeadPosition();
	while(pos)
	{
		CHostUserName pName = pRshd->m_HostUserList.GetNext(pos);
		if (pName == Name)
		{
			// host and user names are in the .rhosts file
			pRshd->m_Lock.Unlock();
			return TRUE;
		}
	}

	pRshd->m_Lock.Unlock();

	// no such host or user name is in the .rhosts file
	return FALSE;
}

BOOL CRshdSocket::OpenErrorSocket(CRshdSocket* pErrorRshd, 
								  WORD nPort, char* HostName)
{
	// create the new socket 
    if (!pErrorRshd->RResvPort())
    {
        GetLog()->LogMsg("OpenErrorSocket", 1, "Cannot create temp socket!");
        return FALSE;
    }

	// set socket option to connect to the client
	if (!pErrorRshd->SetSockOpt(0))
	{
        GetLog()->LogMsg("OpenErrorSocket", 2, "Cannot set socket option!");
		pErrorRshd->Close();
		return FALSE;
	}

	sockaddr_in Addr;
    int Len = sizeof(Addr);
    GetPeerName((sockaddr*)&Addr, &Len);
    Addr.sin_family = PF_INET;
    Addr.sin_port   = htons(nPort);

 	// now, connect to the client port 
	if (!pErrorRshd->Connect((sockaddr*)&Addr, sizeof(Addr)))
    {
        GetLog()->LogMsg("OpenErrorSocket", 3, 
			GetStringByErrorCode(WSAGetLastError()));
		pErrorRshd->Close();
        return FALSE;
    }

	return TRUE;
}

// try to duplicate the BSD rresvport function
// please read UNIX Network Programming (by W. Richard Stevens)
// second edition, P41-43 for more details 
BOOL CRshdSocket::RResvPort()
{
	// prevent from multiple rsh clients get available ports at same time
	CRshd* pRshd = GetRshd();
	pRshd->m_Lock.Lock();
    m_hSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (m_hSocket == INVALID_SOCKET)
	{
		pRshd->m_Lock.Unlock();
        return FALSE;
	}
    
	// static declare can reduce times for 'for' loop to get available port
    static WORD LastPort = IPPORT_RESERVED;
    sockaddr_in Addr;
    Addr.sin_family = AF_INET;
    Addr.sin_addr.s_addr = INADDR_ANY;
	for(WORD nPort = LastPort - 1; ; nPort --)
    {
		// use BSD rresvport (513-1023) only, 
		// but port range (1-1023) should still be OK, 
		// eg. if (nPort == 0) nPort = IPPORT_RESERVED - 1; if you like
        if (nPort == IPPORT_RESERVED / 2) 
            nPort =  IPPORT_RESERVED - 1;
        Addr.sin_port = htons(nPort);
        if (Bind((sockaddr*)&Addr, sizeof(Addr)))
        {
            LastPort = nPort;
			pRshd->m_Lock.Unlock();
            return TRUE;
        }
		// something wrong, no available port any more
        if (WSAGetLastError() != WSAEADDRINUSE)
            break;
    }

    Close();
	pRshd->m_Lock.Unlock();

    return FALSE;
}

BOOL CRshdSocket::ReceiveClientInfo(char Buff[], int Len, int& i)
{
    while(Buff[i++]);
    if(!Buff[i])
    {
        if(Receive(Buff, Len) <= 0)
		{
			// something wrong with the client
			return FALSE;
		}
        i = 0;
    }

	return TRUE;
}

static BOOL BlockFlag;
static void CommandEx(void* pData)
{
	system((char*)pData);
	BlockFlag = FALSE;
}

BOOL CRshdSocket::ExecCommand(CRshdSocket* pErrorRshd, const char* Command)
{
	char  TempFile[256], TempErr[256];
	// get the full temp directory path from environment variables
	char* TempDir = getenv("TEMP");

	// init buffers
	CStr ComBuff = Command;
	memset(TempFile, 0, sizeof(TempFile));
	memset(TempErr, 0, sizeof(TempErr));
	if(TempDir)
		strncpy(TempFile, TempDir, sizeof(TempFile));

	tmpnam(TempFile + strlen(TempFile));
	// redirection on 
	ComBuff += " >";
	ComBuff += TempFile;

	if (m_pRshd->GetWinOSVersion())
	{
        if(TempDir)
            strncpy(TempErr, TempDir, sizeof(TempErr));

        tmpnam(TempErr + strlen(TempErr));
		// redirection 
		ComBuff += " 2>";
		ComBuff += TempErr;
	}

	// execute the dump file command with a new thread
	BlockFlag = TRUE;
	_beginthread(CommandEx, 0, (void*)ComBuff.GetChar());
	int i = 0;
	while(BlockFlag)
	{
		// two seconds waiting for thread to terminate
		Sleep(40);
		if (++ i > 50) break;
	}

	// send the file to client
	if (SendTempFile(TempFile))
		unlink(TempFile);
	else
		return FALSE;

	// if the operating system is Windows NT/2000/XP, 
	// send the error stream to the client
	if (m_pRshd->GetWinOSVersion())
	{
		if (pErrorRshd->m_hSocket != INVALID_SOCKET)
			pErrorRshd->SendTempFile(TempErr);
		else
			SendTempFile(TempErr);
		unlink(TempErr);
	}

	return TRUE;
}

// open the temp file and send it to the client
BOOL CRshdSocket::SendTempFile(const char* TempFile)
{
    char Buff[MSG_LEN];
    int  Len;
    FILE* fp = fopen(TempFile, "r");
    if(!fp)
    {
        GetLog()->LogMsg("SendTempFile", 1,	
			"Cannot open temporary file '%s'", TempFile);
        return FALSE;
    }
    while(!feof(fp))
    {
        Buff[0] = 0;
        fgets(Buff, MSG_LEN, fp);
        Len = strlen(Buff);
        if(Len)
		{
			// send to the Rsh host
            if(Send(Buff, Len) < Len)
            {
                GetLog()->LogMsg("SendTempFile", 2, "Error sending results.");
                break;
            }
		}
    }
    fclose(fp);

	return TRUE;
}

// disconnect to the client
void CRshdSocket::DeleteClientSock()
{
	CRshd* pRshd = GetRshd();
	// iteration of the CClientSockList
	POSITION pos = pRshd->m_ClientList.GetHeadPosition();
	while(pos)
	{
		POSITION pos1 = pos;
		if (this == pRshd->m_ClientList.GetNext(pos))
		{
			ShutDown();
			Close();
			pRshd->m_ClientList.RemoveAt(pos1);
			delete this;
			return;
		}
	}
	assert(false);
}

CRshdConfigFile::CRshdConfigFile(CLock* pLock)
{ 
	m_pLock = pLock; 
	m_IniFile = "Rshd.ini"; 
}

CRshdConfigFile:: CRshdConfigFile(CLock* pLock, CStr IniFile)
{
	m_pLock = pLock; 
	m_IniFile = IniFile; 
}

bool CRshdConfigFile::CheckConfFile()
{
	if (-1 ==  m_IniFile.Find('\\') && -1 ==  m_IniFile.Find(':'))
		m_IniFile = ".\\" + m_IniFile;

	// check if the ini file is there
	if (!CheckExist(m_IniFile))
		return FALSE;

	m_bDebug = GetConfInt("Info", "Debug", 1) ? 1 : 0;

	// get the log file path and name
	m_LogFilePath = GetConfString("Path", "LogFile", "");
	if (m_LogFilePath == "")
		return FALSE;

	// init the log system
	LogInit(m_LogFilePath, "Version 1.02");

	// get the .rhosts file path and name
	m_HostFilePath = GetConfString("Path", "HostFile ", "");
	if (m_HostFilePath == "")
	{
		LogMsg("CheckConfFile", 1, 
			"Host file is missing HostFile entry in [Path] section");
		return FALSE;
	}

	return TRUE;
}

CRshd::CRshd() 
{
	m_bWinVersion  = TRUE;
	m_pServerRshd  = NULL;
	m_pConfile	   = NULL;
}

CRshd::~CRshd()
{ 
	// stop Rshd sevice and memory cleanup
	StopRshdService();
}

void CRshd::StartRshdService()
{
	m_pConfile = new CRshdConfigFile(&m_Lock);
	// open ini file, check it, and initialise log file
	if (!m_pConfile->CheckConfFile())
		return; // something wrong with ini file

	if (!LoadRHostsFile())
		return; // something wrong with .rhosts file

	m_pServerRshd = new CRshdSocket(this);
	// initilise Window 9x/NT/ME/2000/XP socket
	if (!m_pServerRshd->SocketInit())
	{
		m_pConfile->LogMsg("StartRshdService", 1, "Socket init failed.");
		return;
	}

	// create socket and bind the Rshd service port
	if (!m_pServerRshd->Create())
	{
		m_pConfile->LogMsg("StartRshdService", 2, "Create socket failed.");
		return;
	}

	if (!m_pServerRshd->Listen())
	{
		m_pConfile->LogMsg("StartRshdService", 3, "Socket listen failed.");
		return;
	}

	// get operating system version
	m_bWinVersion = WinVersion();
	// accept the rsh client to connect
	m_pServerRshd->Accept(NULL);
}

void CRshd::StopRshdService()
{
	// close all sockets
	POSITION pos = m_ClientList.GetHeadPosition();
	while(pos)
	{
		CRshdSocket* pClientRshd = m_ClientList.GetNext(pos);
		if (pClientRshd)
		{
			// inform all clients the Rshd servive to be shutdown 
			if (pClientRshd->m_hSocket != INVALID_SOCKET)
			{
				char Buff[] = "Rshd servive shutdown";
				pClientRshd->Send(Buff, sizeof(Buff));
			}
			pClientRshd->ShutDown();
			pClientRshd->Close();
			delete pClientRshd;
		}
	}
	m_ClientList.RemoveAll();

	if (m_pServerRshd)
		delete m_pServerRshd;

	// don't call WSACleanup because atexit has register it which
	// will be automatically invoked by system whem Rshd exits !!!
	//WSACleanup();
	
	m_HostUserList.RemoveAll();
	if (m_pConfile)
		delete m_pConfile;
}

BOOL CRshd::LoadRHostsFile()
{
	// open the host file '.rhosts'
	FILE* fp = fopen((char*)m_pConfile->GetHostFileName(), "r");
	if (!fp)
		return FALSE;

	// set delimit
	char Seps[] = " ,\t\n";
	char LineBuff[256];
	CHostUserName HostUser;
	m_HostUserList.RemoveAll();
	while(!feof(fp))
	{
		if (!fgets(LineBuff, sizeof(LineBuff), fp))
		{
			if (feof(fp)) break;
			m_pConfile->LogMsg("LoadRHostsFile", 1, 
				"The host file '.rhosts' is wrong");
			fclose(fp);
			return FALSE;
		}

		char* Token = strtok(LineBuff, Seps);
		// ignore empty line and comment line which start with '#' or ';'
		if (!Token || Token[0] == '#' || Token[0] == ';')
			continue;
		HostUser.HostName = Token; // host name is detected

		Token = strtok(NULL, Seps);
		if (!Token)
			continue; // no user name provided
		HostUser.UserName = Token;

		m_HostUserList.AddTail(HostUser);
	}
	fclose(fp);

	return TRUE;
}

// decide which operating system is running at the computer
// we only identify whether it belongs to Window 9x/ME or NT/2000/XP
BOOL CRshd::WinVersion()
{
	if (GetVersion() & 0x80000000) // Windows 9x/ME
		return FALSE;

	return TRUE; // Windows NT/2000/XP
}

int main(int argc, char* argv)
{
	// hide the console window
	char Title[256];
	if (GetConsoleTitle(Title, sizeof(Title)))
	{
		HWND hWnd = FindWindow(NULL, Title);
		ShowWindow(hWnd, SW_HIDE);
	}

	// start the Rshd service
	CRshd m_Rshd;
	m_Rshd.StartRshdService();

	return 0;
}
