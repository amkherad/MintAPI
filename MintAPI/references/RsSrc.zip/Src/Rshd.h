//-------------------------------------------------------------------------
//  Rshd.h
//
//  Generic C++ remote shell daemon header file
//
//  Execution environment: Win32
//
//  Created: 2002
//
//  by Yuantu Huang
//-------------------------------------------------------------------------

#ifndef __RSHD_H__
#define __RSHD_H__

#include "WinSocketEx.h"
#include "List.h"
#include "Str.h"
#include "Confile.h"

class CRshd;
class CRshdConfigFile;

// client socket
class CRshdSocket : public CWinSocketEx
{
// Attributes
public:
	CRshd* GetRshd() const		{ return m_pRshd; }
	CRshdConfigFile* GetLog();

// Operations
public:
	CRshdSocket(CRshd* pRshd) { m_pRshd = pRshd; }

	BOOL CheckClienInfo(char* HostName);
	void OpenTempSocket();
	BOOL CheckPort(WORD nPort);
	BOOL CheckHostAndUserName(const char* HostName, const char* UserName);
	BOOL OpenErrorSocket(CRshdSocket* pErrorRshd, WORD nPort, char* HostName);
	BOOL RResvPort();
	BOOL ReceiveClientInfo(char Buff[], int Len, int& i);
	BOOL ExecCommand(CRshdSocket* pErrorRshd, const char* Command);
	BOOL SendTempFile(const char* FileName);

	void DeleteClientSock();

// Overrides
public:
	virtual ~CRshdSocket(){};
	virtual BOOL Create(UINT nSocketPort = 0, int nSocketType = SOCK_STREAM, 
		char* pSocketAddress = NULL);
	virtual BOOL Accept(CWinSocket* pClientSock, 
		sockaddr* pSockAddr = NULL, int* pSockAddrLen = NULL);

private:
	CRshd* m_pRshd;
};

// connected client holder
typedef List<CRshdSocket*, CRshdSocket*> CClientSockList;

struct CHostUserName // link to the .rhosts file
{
	CStr HostName;
	CStr UserName;
	bool operator ==(const CHostUserName& Name)
	{
		return HostName == Name.HostName && UserName == Name.UserName;
	}
};

// host and user name holder
typedef List<CHostUserName, CHostUserName&> CHostUserNameList;

// ini file and log file object
class CRshdConfigFile : public CConfigFile
{
public:
	CRshdConfigFile(CLock* pLock);
	CRshdConfigFile(CLock* pLock, CStr IniFile);
	bool CheckConfFile();

	virtual void Lock()		{ m_pLock->Lock(); }
	virtual void Unlock()	{ m_pLock->Unlock(); }

	CStr GetHostFileName() const	{ return  m_HostFilePath; }

private:
	CStr m_LogFilePath;
	CStr m_HostFilePath;
	CLock* m_pLock;
};

class CRshd
{
public:
	CRshd();
	~CRshd();

// attributes
	CClientSockList		m_ClientList;
	CHostUserNameList	m_HostUserList;
	CRshdConfigFile*	m_pConfile;
	CLock				m_Lock;

	CRshdConfigFile* GetLog() { return m_pConfile; }

// Operations
	void StartRshdService();
	void StopRshdService();

	BOOL GetWinOSVersion()	{ return m_bWinVersion; }
	BOOL LoadRHostsFile();

private:
	BOOL m_bWinVersion;
	BOOL WinVersion();
	CRshdSocket* m_pServerRshd;
};

#endif
